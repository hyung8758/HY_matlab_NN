% Network Building Function
% This is the function for building a 'N' structure for running DNN

                                                            % Hyungwon Yang
                                                            % 
                                                            % 2016. 02. 26
                                                            % EMCS lab

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function N = Netbuild(inputData, targetData, training, testing,...
                      fineTrainEpoch, fineLearningRate, momentum, batchSize,...
                      normalize, hiddenLayers, errorMethod, hiddenActivation,...
                      outputActivation, plotOption, preTrainEpoch, preLearningRate)

% Input and output infromation
[inputNumber,inputUnit] = size(inputData);
[~,outputUnit] = size(targetData);

% batch size exception.
if batchSize > inputNumber
    batchSize = inputNumber;
    warning(['Batch size is downsized, '...
        'because it is larger than the input number.\n'...
        '\t Adjusted batch size: %d\n'],batchSize)
end
% batch size readjustment
if rem(inputNumber,batchSize) ~= 0
   restNum = rem(inputNumber,batchSize);
    while restNum ~= 0
        batchSize = batchSize - 1;
        restNum = rem(inputNumber,batchSize);
    end
    warning(['Batch size has been adjusted to prevent the dimension mismatch'...
        ' problem.\n'...
        '\t Adjusted batch size: %d\n'],batchSize)
end

% Initializing weights and biases.
% Hidden Layer Information
hiddenStructure = hiddenLayers;

% the number of hidden layers and units
layerStructure{1} = inputUnit;
for hls = 2:length(hiddenStructure)+1
    layerStructure{hls} = hiddenStructure(hls-1);
end
layerStructure{length(hiddenStructure)+2} = outputUnit;

hiddenLayerNumber = length(layerStructure);

visualBiasValue = log10((1/layerStructure{1}) / (1-(1/layerStructure{1})));
biasMatrix{1} = repmat(visualBiasValue,batchSize,layerStructure{1});

range = 0.1;
for i = 1:hiddenLayerNumber-1
    
    % Weight Matrix
    weightMatrix{i} = randn(layerStructure{i},layerStructure{i+1})* range * 2 - range;
    % Bias Matrix
    visualBiasValue = log10((1/layerStructure{i+1}) / (1-(1/layerStructure{i+1})));
    biasMatrix{i+1} = repmat(visualBiasValue,batchSize,layerStructure{i+1});
    layerError{i} = zeros(1,1);
end

ERROR{1} = layerError;
WEIGHT{1} = weightMatrix;
BIAS{1} = biasMatrix;
error_history = [];

% Structuring
N = struct('inputData',inputData,'targetData',targetData,'training',training,'testing',testing,...
    'fineTrainEpoch',fineTrainEpoch,'fineLearningRate',fineLearningRate,...
    'momentum',momentum,'batchSize',batchSize,'normalize',normalize,'hiddenLayers',hiddenLayers,...
    'errorMethod',errorMethod,'plotOption',plotOption,'preTrainEpoch',preTrainEpoch,...
    'preLearningRate',preLearningRate,'hiddenActivation',hiddenActivation,...
    'outputActivation',outputActivation,'layerError',ERROR,'weight',WEIGHT,...
    'bias',BIAS,'errorInfo',error_history);
