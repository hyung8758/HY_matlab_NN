% For randomizing input orders, this function shuffles all the
% batch indices. 
                                                            % Hyungwon Yang
                                                            % 
                                                            % 2016. 02. 26
                                                            % EMCS lab
                                                            
function shakedBatch = shakeBatch(inputNumber,batchSize)

batchNumber= inputNumber/batchSize;
% Generate mixed batch indices.
batchBox = randperm(inputNumber);
start = 0;
final = 0;
for i = 1:batchNumber
    start = final + 1;
    final = final + batchSize;
    batchIndex{i,1}= batchBox(start:final);
end

% Output
shakedBatch = batchIndex;