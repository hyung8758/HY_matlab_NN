This is HY_matlab_NN. 
                                                              Hyungwon Yang
                                                                 2015.02.02
                                                                   EMCS lab

Machine learning toolbox based on matlab.



Linux and MacOSX
(This script is not tested on Window)
---------------------------------------------------------------------------

Matlab R2015a
(This script was not tested on the other versions.)



PREREQUISITE
---------------------------------------------------------------------------
1. Data preprocessing: Your data should be pre-processed before setting it 
 on the DNN. Please refer to preprocessing instrcution described as below.

 - Your data should contain 2 variables and be saved as 'inputData' and
  'targetData'. As the name implies, input data should be named 'inputData',
   and target or output data should be named 'targetData'.

 - Variable structure should be examples * features matrix. For examples,
   if your input data has 40 features and you have 1,000 of that kind of
   feature data. Data structure will be 1000 * 40 matrix.

 - For RBM stacking, your input data needs to be normalized scaled between
   0 to 1. (Choose nomalize option 'on' if you didn't normalize your data)
   Normalizing target data is not requisite, since the RBM training is 
   unsupervised.

 - In classification problem, target data should be cosisted of binary 
   information: 0 or 1. For example, if your target data is MNIST and one 
   of the target data is digit 6, then your target data will look like
   [0 0 0 0 0 1 0 0 0 0].



CONTENTS
---------------------------------------------------------------------------
Deep Neural Network (DNN) for classification & curve-fitting problems.

 - DNN
 DNN model to solve classification and curve-fitting problems. For beginners, 
 remain all the default parameters in order to test the given datasets and 
 try to understand the layer structures and its results.
 The users are highly recommended to adjust the parameters in order to 
 improve performance.

 - runDNN
 It contains a whole procedure of training & testing data by machine learning.
 Please follow the instrcution for better undestadning of its usage.

 - Netbuild
 This function builds a main structrue that contains training data and 
 parameters.

		
CONTACTS
---------------------------------------------------------------------------

Hosung Nam / hnam@korea.ac.kr
Hyungwon Yang / hyung8758@gmail.com


VERSION HISTORY
---------------------------------------------------------------------------
1.0. (2015.02.02)
     5 scripts were uploaded. Each script works independently. Therefore,
     users should select a specific script for training data.
     : ANN for classificiaton and curve-fitting,
       DBN for classification and curve-fitting,
       Netbuild function for building networks
       Sample training datasets

2.0. (2015.03.05)
     4 types of ANN and DBN are combined. By adjusting parameters, users can
     use ANN or DBN based on their deisre. 

2.1. (2015.03.06)
     Batch size problem fixed.
     Plotting added: error change, confusion, roc.
     (it is displayed nicely when the monitor is 13 inches.)

2.2. (2015.3.8)
     Remained batch problem has been perfectly solved.
    


