HY_matlab_NN. 
                                                              Hyungwon Yang
                                                                 2016.06.14
                                                                   EMCS lab

Dataset instruction.

From ver.2.7, sample datasets such as MNIST and CIFAR10 are not provided 
as mat file but the users have to download those sample files themselves.
However, don't worry because functions for downloading sample datasets
are supported. 

Please run 'po' function before execute the functions below.

1. MNIST 
Type 'download_mnist' in the command line.

2. CIFAR10
Type 'download_cifar10' in the command line.

