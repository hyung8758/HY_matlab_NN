% ANN_batch: CurveFitting problem (regression)
% I recommend you to use ANNforNR_online.m instead of this.
                                                            % Hyungwon Yang
                                                            % 2015.12.03
                                                            % EMCS lab

clear;clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% loading data and setting data name
% row = input feature, col = input examples
load inout_2
% train, cross-validation, and test set
train_in = mfcc_V(:,1:13000);
train_out = art_V(:,1:13000);
% val_in = mfcc_V(:,8001:16000); % 10001:13159
% val_out = art_V(:,8001:16000);
test_in = mfcc_V(:,13001:16000); % 13160:end
test_out = art_V(:,13001:16000);

% initializing default set
% momentum % learning rate
momentum = 0.9;
lr = 0.001;
num_epoch = 100;
% error and recording
sse = 10;
% input size
[inputUnit,num_train] = size(train_in);
% output size
[outputUnit,outcol] = size(train_out);
% batch
batchSize = 11;
% input for start
X = train_in;
% output for start
Y = train_out;
% the number of input
num_input = size(X,1);
% the number of ooutput
num_output = size(Y,1);
% the number of hidden units
hiddenUnit = 300;
% bias for input layer
hBiasMatrix = ones(batchSize,hiddenUnit);
% bias for hidden layer
oBiasMatrix = ones(batchSize,num_output);
% input to hid weight
range = 0.1;
ihMatrix = rand(num_input, hiddenUnit) * range * 2 - range ;
% hid to output weight
hoMatrix = rand(hiddenUnit, num_output) * range * 2 - range;

% create batches.
num_batch = ceil(num_train/batchSize);
batchLine= repmat(1:num_batch, 1, batchSize);
batchLine= batchLine(1:num_train);
batchLine = batchLine(randperm(num_train));

% batch distribution.
start = 0;
final = 0;
for i = 1:num_batch
    start = final + 1;
    final = final + batchSize;
    testInput{i}= X(:,start:final);
    testTarget{i}= Y(:,start:final);
end

%% Training Session.

for epoch = 1:num_epoch
    
    % batch training.
    for batch = 1:num_batch
        inputPattern = testInput{batch};
        outputPattern = testTarget{batch};
        % input to hidden layer
        hiddenStorage = inputPattern' * ihMatrix + hBiasMatrix;
        hiddenActivation = logistic(hiddenStorage);

        % hidden to output layer
        hiddenStorage = hiddenActivation * hoMatrix + oBiasMatrix;
        % no sigmoid activation.
        outputActivation = hiddenStorage;

        % error calculation
        outputError = (outputPattern' - outputActivation);
        hiddenError = outputError * hoMatrix' .* (hiddenActivation .* (1 - hiddenActivation));
    
        % Weight and bias update
        ihMatrix = ihMatrix + (lr * inputPattern * hiddenError) * (1/batchSize) ;
        hoMatrix = hoMatrix + (lr * hiddenActivation'* outputError) * (1/batchSize);
        hBiasMatrix = hBiasMatrix + (lr * hiddenError) * (1/batchSize);
        oBiasMatrix = oBiasMatrix + (lr * outputError) * (1/batchSize);
       
    end
  
    % Weight and bias update
%     Wnew_1 = Wprev_1 + lr * input_x * (1/batchSize) * hid_error ;
%     Wnew_2 = Wprev_2 + lr * hid_result' * (1/batchSize) * out_error;
%     b_1 = b_1 + lr * hid_error;
%     b_2 = b_2 + lr * out_error;
    
    % error check and display
    sse = trace(outputError' * outputError);
    fprintf('The error: %f\n ',sse)
    if sse < 1e-6
        break
    end
end

%% Testing Session.
testInputPattern = test_in;
testOutputPattern = test_out;
num_test = size(test_in,2);

% batch distribution.
start = 0;
final = 0;
num_batch= ceil(num_test/batchSize);
for i = 1:num_batch
    start = final + 1;
    final = final + batchSize;
    testInput{i} = testInputPattern(:,start:final);
end

% test batch
testResult = [];
for batch = 1:num_batch
    
    testHiddenStorage = logistic(testInput{num_batch}' * ihMatrix + hBiasMatrix);
    testOutputStorage = testHiddenStorage * hoMatrix + oBiasMatrix;
    result = testOutputStorage;
    testResult = [testResult;result];
end

corval = corrcoef(testOutputPattern,testResult');

plot(testOutputPattern,testResult','ok')
title(sprintf('r = %f',corval(1,2)),'fontsize',15);

% error calculation: MSE check
testOutputError = (testOutputPattern' - testResult).^2;
resultArray = sum(testOutputError) / 2;
MSE = floor(sum(resultArray)/num_test);
fprintf('MSE: %d\n',MSE)

