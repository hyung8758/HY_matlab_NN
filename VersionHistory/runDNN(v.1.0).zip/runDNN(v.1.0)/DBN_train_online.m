% DBN_train: CurveFitting problem (regression)
                                                            % Hyungwon Yang
                                                            % 
                                                            % 2015.12.07
                                                            % EMCS lab

clear;clc;close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variable set up    
% input and output numbers
num_input = 12000;
num_output = 12000;
num_testInput = 4000;
num_testOutput = 4000;
% 
% momentum and learning rate
momentum = 0.9;
pre_learningRate = 0.1;
fine_learningRate = 0.001;
% epoch 
preTrainEpoch = 10;
fineTuneEpoch = 20;
MSE_epoch = 5;

% loading data and setting data name
% row = input feature, col = input examples
load inout_2

% data normalization with sigmoid function (between 0 to 1)
mfcc_V = logistic(mfcc_V);

% This normalization method is inappropriate for DBN. 
% (x-min(x))/(max(x)-min(x))
% up = bsxfun(@minus,mfcc_V,min(mfcc_V));
% down = max(mfcc_V) - min(mfcc_V);
% mfcc_V = bsxfun(@rdivide,up,down);

% data distribution
%train, (cross-validation), and test set
train_in = mfcc_V(:,1:num_input); 
train_out = art_V(:,1:num_output);
test_in = mfcc_V(:,num_input+1:num_input+num_testInput); 
test_out = art_V(:,num_output+1:num_output+num_testOutput);

inputPattern{1} = train_in;
outputPattern = train_out;
testInputPattern = test_in;
testOutputPattern = test_out;

% the number of hidden layers and units
layerStructure = {39, 50, 50, 50, 16};
num_hiddenLayer = length(layerStructure);
% input size
[inputUnit,num_train] = size(train_in);
% output size
[outputUnit,~] = size(train_out);
% test input size
[testInputUnit,num_test] = size(test_in);
% test output size
[testOutputUnit,~] = size(test_out);


% value assignment.
visualBiasValue = log10((1/layerStructure{1}) / (1-(1/layerStructure{1})));
biasMatrix{1} = repmat(visualBiasValue,1,layerStructure{1});
range = 0.1;
for i = 1:num_hiddenLayer-1
    
    % Weight Matrix
    weightMatrix{i} = randn(layerStructure{i},layerStructure{i+1})* range * 2 - range ;
    % Bias Matrix
    visualBiasValue = log10((1/layerStructure{i+1}) / (1-(1/layerStructure{i+1})));
    biasMatrix{i+1} = repmat(visualBiasValue,1,layerStructure{i+1});
    layerError{i} = zeros(1,1);
end

% The number of weight matrix for pre-training / last weight matrix is 
% reserved for fine-tuning.
trainingWeightMatrixRange =length(weightMatrix) - 1;
currentVisualLayer = 1:trainingWeightMatrixRange;
currentHiddenLayer = 2:trainingWeightMatrixRange + 1;
weightIndex = 1:num_hiddenLayer -1;
hiddenIndex = 1:num_hiddenLayer; 

% error and recording
sse_history = [];
sse_keep = [];
MSE_history = [];
fprintf('DBN with RBM stacking for curve fitting\nTraining Information:\n')
fprintf('   Input features: %d, Output features: %d, examples: %d\n',...
    inputUnit,outputUnit,num_train)

%% Pre-training Session
tic
fprintf('Pre_training the model...\n')
% hidden layers
for hidden = 1:trainingWeightMatrixRange
    fprintf('   %d Hidden layer units: %d\n',...
        hidden,layerStructure{1+hidden})
    
    % pre-training epochs
    for epoch = 1:preTrainEpoch
        
        vhMatrix = weightMatrix{hidden};
        vBiasMatrix = biasMatrix{currentVisualLayer(hidden)};
        hBiasMatrix = biasMatrix{currentHiddenLayer(hidden)};

        % training all examples
        rand_num = randperm(num_train);
        for num = rand_num
            
            layerForPT = inputPattern{hidden}(:,num);
            % visual0
            visual0Array = layerForPT;
            % hidden0
            hidden0 = visual0Array' * vhMatrix + hBiasMatrix;
            hidden0Array = BinarySigmoid(momentum,hidden0);

            %%% visual1 
            visual1 = vhMatrix * hidden0Array' + vBiasMatrix';
            visual1Array = BinarySigmoid(momentum,visual1);
            % hidden1
            hidden1 = visual1Array' * vhMatrix + hBiasMatrix;
            hidden1Array = BinarySigmoid(momentum,hidden1);
            
            % update weights and biases
            vhMatrix = vhMatrix + pre_learningRate * (visual0Array * hidden0Array - visual1Array * hidden1Array);
            vBiasMatrix = vBiasMatrix + pre_learningRate * (visual0Array - visual1Array)';
            hBiasMatrix = hBiasMatrix + pre_learningRate * (hidden0Array - hidden1Array);
            
            % input update
            inputPattern{hidden+1}(:,num) = hidden0Array;
            
        end
        
        % allocate weights and biases.
        weightMatrix{hidden} = vhMatrix;
        biasMatrix{hidden} = vBiasMatrix;
        biasMatrix{hidden+1} = hBiasMatrix;

        fprintf('%d/%d Hidden layer, %d/%d Epoch\n',...
        hidden,trainingWeightMatrixRange,epoch,preTrainEpoch)
    end

end
fprintf('\nPre_training complete. Prepare for Fine_Tuning...\n\n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fine-tuning Session
% Checking MSE by running fine_tunning with 20epochs and testing.

fprintf('Fine_tuning the model...\n')
for MSE_check = 1:MSE_epoch

    fprintf('Grand Epoch: %d/%d\n',MSE_check,MSE_epoch)
    % forward process
    for epoch = 1:fineTuneEpoch

        % FNN for each example: vector by vector
        rand_num = randperm(num_train);
        %rand_num = 1:12000;
        for num = rand_num

            layerActivation{1} = inputPattern{1}(:,num);

            for hidden = 1:num_hiddenLayer - 2

                weight = weightMatrix{hidden};
                bias = biasMatrix{hidden+1};

                inPattern = layerActivation{hidden};
                layerStore = inPattern' * weight + bias;
                layerActive = BinarySigmoid(momentum,layerStore)';
                layerMemory{hidden} = layerActive;
                layerStorage{hidden+1} = layerStore';

                layerActivation{hidden+1} = layerMemory{hidden};
            end

            %last up without sigmoid
            weight = weightMatrix{end};
            bias = biasMatrix{end};

            inPattern = layerActivation{num_hiddenLayer-1};
            layerStore = inPattern' * weight + bias;
            layerMemory{num_hiddenLayer-1} = layerStore;
            layerStorage{num_hiddenLayer} = layerStore;

            layerActivation{num_hiddenLayer} = layerMemory{end};

            %error calculation
            outputLayerIndex = num_hiddenLayer - 1;
            layerError{outputLayerIndex} = ...
                outputPattern(:,num) - layerActivation{outputLayerIndex+1}';
            layerError{outputLayerIndex-1} = ...
                weightMatrix{outputLayerIndex} * layerError{outputLayerIndex};
            % sigmoid error calculation
            for i = length(layerError) - 1: -1: 1
                layerError{i} = weightMatrix{i+1} * layerError{i+1}...
                    .* ((layerActivation{i+1} .* (1 - layerActivation{i+1})) * momentum);
            end

            % update weights and biases.
            for i = 1:length(weightMatrix)
                weightMatrix{i} = weightMatrix{i}...
                    + fine_learningRate * layerActivation{i} * layerError{i}';
            end
            for i = 2:length(biasMatrix)
                biasMatrix{i} = biasMatrix{i} + fine_learningRate * layerError{i-1}';
            end
            
        sse = trace(layerError{outputLayerIndex}' * layerError{outputLayerIndex});
        sse_keep = [sse_keep sse];            
        
        end

        %sse = trace(layerError{outputLayerIndex}' * layerError{outputLayerIndex});
        %sse_keep = [sse_keep sse];

        % error check and display
        sse_sum = sum(sse_keep)/num_train;
        sse_history = [sse_history sse_sum];
        fprintf('Fine_Tuning %d/%d: error is %f\n',epoch,fineTuneEpoch,sse_sum)
        sse_keep = [];


    end
end
fprintf('DBN process complete.\n\n')

%% Testing Session

fprintf('Testing the trained model...\nTesting Information:\n')
fprintf('   Input features: %d, Output features: %d, examples: %d\n',...
    inputUnit,outputUnit,num_test)

for num = 1:num_test
    
    testLayerActivation{1} = testInputPattern(:,num);
    
    for hidden = 1:num_hiddenLayer - 2
        
        weight = weightMatrix{hidden};
        bias = biasMatrix{hidden+1};
        
        testInPattern = testLayerActivation{hidden};
        testLayerStore = testInPattern' * weight + bias;
        testLayerActive = BinarySigmoid(momentum,testLayerStore)';
        testLayerMemory{hidden} = testLayerActive;
        testLayerStorage{hidden+1} = testLayerStore';
        
        testLayerActivation{hidden+1} = testLayerMemory{hidden};
    end
    
    %last up without sigmoid
    weight = weightMatrix{end};
    bias = biasMatrix{end};
    
    testInPattern = testLayerActivation{num_hiddenLayer-1};
    testLayerStore = testInPattern' * weight + bias;
    testLayerMemory{num_hiddenLayer-1} = testLayerStore;
    testLayerStorage{num_hiddenLayer} = testLayerStore;
    
    testLayerActivation{num_hiddenLayer} = testLayerMemory{end};
    stackedOutput(num,:) = testLayerActivation{num_hiddenLayer};
    
end

% error calculation
testOutputError = (testOutputPattern' - stackedOutput).^2;
resultArray = sum(testOutputError) / 2;
MSE = floor(sum(resultArray)/num_test);
fprintf('Testing complete.\nMSE: %d\n',MSE)

total_time = toc;
fprintf('total duration: %d seconds\n\n',floor(total_time))
%% pearson r value and plotting.

% error trace plotting
subplot(1,2,1)
num_epoch = fineTuneEpoch * MSE_epoch;
plot([1:num_epoch],sse_history,'o-k')
xlabel('Epoch Number','fontsize',12)
ylabel('Error','fontsize',12)
title('Error change','fontsize',15)

% correlation coefficient r and relation plotting
fprintf('Correlation coefficient r calculating...\n')
corval = corrcoef(testOutputPattern,stackedOutput');
Rvalue = corval(1,2);

% Plotting the error history and correlations between real data and
% predicted data.
subplot(1,2,2)
fprintf('plotting correlation... Rvalue: %f\n',Rvalue)
plot(testOutputPattern,stackedOutput','ok')
xlabel('Target Data','fontsize',12)
ylabel('Output Data','fontsize',12)
title(sprintf('r = %f',Rvalue),'fontsize',15);
axis([-60 20 -60 20])


