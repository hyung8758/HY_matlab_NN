clear;clc;close all
% DNN network 
%load small_mnist
load mfcc_art

% Input Information
trainInput = [train_in];
trainTarget = [train_out];

% Output Information
testInput = [test_in];
testTarget = [test_out];

% parameters
fineTrainEpoch = 25;
fineLearningRate = 0.0001;
momentum = 0.9;
batchSize = 1;
pretrain = 0; % 1: on, 0: off

% Hidden structures
hiddenLayers = [50 50 50];

% Error
errorMethod = 'MSE'; % 'CE','MSE'

% Plot
% choice of plotting the result data or not.
plotOption = 1; % 1: on, 2: off

% RBM option
preTrainEpoch = 10;
preLearningRate = 0.01;

% Activation option
hiddenActivation = 'sigmoid'; % sigmoid, tanh
outputActivation = 'linear'; % sigmoid, softmax, linear



% Struturing

N = struct('trainInput',trainInput,'trainTarget',trainTarget,'testInput',testInput,...
    'testTarget',testTarget,'fineTrainEpoch',fineTrainEpoch,'fineLearningRate',fineLearningRate,...
    'momentum',momentum,'batchSize',batchSize,'pretrain',pretrain,'hiddenLayers',hiddenLayers,...
    'errorMethod',errorMethod,'plotOption',plotOption,'preTrainEpoch',preTrainEpoch,...
    'preLearningRate',preLearningRate,'hiddenActivation',hiddenActivation,'outputActivation',outputActivation);


%% DO NOT CONTAIN...
% 1. NORMALIZATION: users should normalize the data before using this
% function.
% 2. 



