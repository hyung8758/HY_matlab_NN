% DBN_train : classification problem

% give a option!!!!!                                                            % Hyungwon Yang
% hidden > sigmoid or tanh?
% hidden to output > sigmoid, softmax, linear

                                                            % 2016.02.14
                                                            % EMCS lab

clear;clc;close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variable set up    
% input and output numbers
num_input = 5000;
num_output = 5000;
num_testInput = 1000;
num_testOutput = 1000;
% 
% momentum and learning rate
momentum = 0.9;
pre_learningRate = 0.01;
fine_learningRate = 0.01;
% epoch 
preTrainEpoch = 1;
fineTuneEpoch = 2;
MSE_epoch = 1;

% loading data and setting data name
% row = input feature, col = input examples
load mnist_classify

% data normalization with sigmoid function (between 0 to 1)
%data = logistic(data);
%testdata = logistic(testdata);
%data = data/255;
%testdata = data/255;

% This normalization method is inappropriate for DBN. 
% (x-min(x))/(max(x)-min(x))
% up = bsxfun(@minus,mfcc_V,min(mfcc_V));
% down = max(mfcc_V) - min(mfcc_V);
% mfcc_V = bsxfun(@rdivide,up,down);

% data distribution
%train, (cross-validation), and test set
train_in = data;
train_out = labels;
test_in = testdata;
test_out = testlabels;

% Target data reconstruction
% extract the target digits
F_train_out= unique(train_out);
F_test_out = unique(test_out);
num_class = length(F_train_out);

% constrct the target array
train_target = zeros(num_output, num_class);
test_target = zeros(num_testOutput,num_class);

for num =1:num_class
    train_target(train_out==F_train_out(num),num)=1;
    test_target(test_out==F_test_out(num),num)=1;
end

% Distribute the data into training and testing format arrays
inputPattern{1} = train_in;
outputPattern = train_target;
testInputPattern = test_in;
testOutputPattern = test_target;

% input size
[num_train,inputUnit] = size(train_in);
% output size
[~,outputUnit] = size(train_target);
% test input size
[num_test,testInputUnit] = size(test_in);
% test output size
[~,testOutputUnit] = size(test_target);
% the number of hidden layers and units move it to the top
layerStructure = {inputUnit, 100, 100, 100, num_class};
num_hiddenLayer = length(layerStructure);

% value assignment.
visualBiasValue = log10((1/layerStructure{1}) / (1-(1/layerStructure{1})));
biasMatrix{1} = repmat(visualBiasValue,1,layerStructure{1});
range = 0.1;
for i = 1:num_hiddenLayer-1
    
    % Weight Matrix
    weightMatrix{i} = randn(layerStructure{i},layerStructure{i+1})* range * 2 - range ;
    % Bias Matrix
    visualBiasValue = log10((1/layerStructure{i+1}) / (1-(1/layerStructure{i+1})));
    biasMatrix{i+1} = repmat(visualBiasValue,1,layerStructure{i+1});
    layerError{i} = zeros(1,1);
end

% The number of weight matrix for pre-training / last weight matrix is 
% reserved for fine-tuning.
trainingWeightMatrixRange =length(weightMatrix) - 1;
currentVisualLayer = 1:trainingWeightMatrixRange;
currentHiddenLayer = 2:trainingWeightMatrixRange + 1;
weightIndex = 1:num_hiddenLayer -1;
hiddenIndex = 1:num_hiddenLayer; 

% error and recording
sse_history = [];
sse_keep = [];
MSE_history = [];
fprintf('DBN with RBM stacking for classification\nTraining Information:\n')
fprintf('   Input features: %d, Output features: %d, examples: %d\n',...
    inputUnit,outputUnit,num_train)

%% Pre-training Session
tic
fprintf('Pre_training the model...\n')
% hidden layers
for hidden = 1:trainingWeightMatrixRange
    fprintf('   %d Hidden layer units: %d\n',...
        hidden,layerStructure{1+hidden})
    
    % pre-training epochs
    for epoch = 1:preTrainEpoch
        
        vhMatrix = weightMatrix{hidden};
        vBiasMatrix = biasMatrix{currentVisualLayer(hidden)};
        hBiasMatrix = biasMatrix{currentHiddenLayer(hidden)};

        % training all examples
        rand_num = randperm(num_train);
        for num = rand_num
            
            layerForPT = inputPattern{hidden}(num,:);
            % visual0
            visual0Array = layerForPT;
            % hidden0
            hidden0 = visual0Array * vhMatrix + hBiasMatrix;
            hidden0Array = BinarySigmoid(momentum,hidden0);

            %%% visual1 
            visual1 = vhMatrix * hidden0Array' + vBiasMatrix';
            visual1Array = BinarySigmoid(momentum,visual1);
            % hidden1
            hidden1 = visual1Array' * vhMatrix + hBiasMatrix;
            hidden1Array = BinarySigmoid(momentum,hidden1);
            
            % update weights and biases
            vhMatrix = vhMatrix + pre_learningRate * (visual0Array' * hidden0Array - visual1Array * hidden1Array);
            vBiasMatrix = vBiasMatrix + pre_learningRate * (visual0Array - visual1Array');
            hBiasMatrix = hBiasMatrix + pre_learningRate * (hidden0Array - hidden1Array);
            
            % input update
            inputPattern{hidden+1}(num,:) = hidden0Array;
            
        end
        
        % allocate weights and biases.
        weightMatrix{hidden} = vhMatrix;
        biasMatrix{hidden} = vBiasMatrix;
        biasMatrix{hidden+1} = hBiasMatrix;

        fprintf('%d/%d Hidden layer, %d/%d Epoch\n',...
        hidden,trainingWeightMatrixRange,epoch,preTrainEpoch)
    end

end
fprintf('\nPre_training complete. Prepare for Fine_Tuning...\n\n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fine-tuning Session
% Checking MSE by running fine_tunning with 20epochs and testing.

fprintf('Fine_tuning the model...\n')
for MSE_check = 1:MSE_epoch

    fprintf('Grand Epoch: %d/%d\n',MSE_check,MSE_epoch)
    % forward process
    for epoch = 1:fineTuneEpoch

        % FNN for each example: vector by vector
        rand_num = randperm(num_train);
        %rand_num = 1:12000;
        for num = rand_num

            layerActivation{1} = inputPattern{1}(num,:);
            train_ce = train_target(num,:);

            for hidden = 1:num_hiddenLayer - 2

                weight = weightMatrix{hidden};
                bias = biasMatrix{hidden+1};

                inPattern = layerActivation{hidden};
                layerStore = inPattern * weight + bias;
                layerActive = BinarySigmoid(momentum,layerStore);
                layerMemory{hidden} = layerActive;
                layerStorage{hidden+1} = layerStore';

                layerActivation{hidden+1} = layerMemory{hidden};
            end

            %last up with softmax
            weight = weightMatrix{end};
            bias = biasMatrix{end};

            inPattern = layerActivation{num_hiddenLayer-1};
            layerStore = inPattern * weight + bias;
            layerMemory{num_hiddenLayer-1} = ml_softmax(layerStore);
            layerStorage{num_hiddenLayer} = layerStore;

            layerActivation{num_hiddenLayer} = layerMemory{end};

            %error calculation
            outputLayerIndex = num_hiddenLayer - 1;
            layerError{outputLayerIndex} = ...
                train_ce - layerActivation{outputLayerIndex+1};
            layerError{outputLayerIndex-1} = ...
                layerError{outputLayerIndex} * weightMatrix{outputLayerIndex}' ;
            % sigmoid error calculation
            for i = length(layerError) - 1: -1: 1
                layerError{i} = layerError{i+1} * weightMatrix{i+1}'...
                    .* ((layerActivation{i+1} .* (1 - layerActivation{i+1})) * momentum);
            end

            % update weights and biases.
            for i = 1:length(weightMatrix)
                weightMatrix{i} = weightMatrix{i}...
                    + fine_learningRate * layerActivation{i}' * layerError{i};
            end
            for i = 2:length(biasMatrix)
                biasMatrix{i} = biasMatrix{i} + fine_learningRate * layerError{i-1};
            end
            
        sse = -sum(train_ce * log(layerMemory{end})');
        sse_keep = [sse_keep sse];            
        
        end

        % error check and display
        sse_sum = sum(sse_keep)/num_train;
        sse_history = [sse_history sse_sum];
        fprintf('Fine_Tuning %d/%d: error is %f\n',epoch,fineTuneEpoch,sse_sum)
        sse_keep = [];


    end
end
fprintf('DBN process complete.\n\n')

%% Testing Session

fprintf('Testing the trained model...\nTesting Information:\n')
fprintf('   Input features: %d, Output features: %d, examples: %d\n',...
    inputUnit,outputUnit,num_test)

for num = 1:num_test
    
    testLayerActivation{1} = testInputPattern(num,:);
    
    for hidden = 1:num_hiddenLayer - 2
        
        weight = weightMatrix{hidden};
        bias = biasMatrix{hidden+1};
        
        testInPattern = testLayerActivation{hidden};
        testLayerStore = testInPattern * weight + bias;
        testLayerActive = BinarySigmoid(momentum,testLayerStore);
        testLayerMemory{hidden} = testLayerActive;
        testLayerStorage{hidden+1} = testLayerStore';
        
        testLayerActivation{hidden+1} = testLayerMemory{hidden};
    end
    
    %last up with softmax
    weight = weightMatrix{end};
    bias = biasMatrix{end};
    
    testInPattern = testLayerActivation{num_hiddenLayer-1};
    testLayerStore = testInPattern * weight + bias;
    testLayerMemory{num_hiddenLayer-1} = ml_softmax(testLayerStore);
    testLayerStorage{num_hiddenLayer} = testLayerStore;
    
    testLayerActivation{num_hiddenLayer} = testLayerMemory{end};
    stackedOutput(num,:) = testLayerActivation{num_hiddenLayer};
    
    max_idx = max(testLayerActivation{num_hiddenLayer});
    pred_result = find(testLayerActivation{num_hiddenLayer} == max_idx);
    test_result = find(test_target(num,:) == 1);
    
    if pred_result == test_result;
        resultArray(num) = 1;
    else
        resultArray(num) = 0;
    end

end

% accuracy calculation based on the prediction
testAccuracy = round((sum(resultArray) / num_test)*100,2);
fprintf('Testing complete.Test Accuracy: %4.2f\n',testAccuracy)

total_time = toc;
fprintf('total duration: %d seconds\n\n',floor(total_time))
