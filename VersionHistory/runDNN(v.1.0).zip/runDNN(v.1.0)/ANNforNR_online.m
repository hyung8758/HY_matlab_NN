% ANN_online : CurveFitting problem (regression)
                                                            % Hyungwon Yang
                                                            % 2015.12.02
                                                            % EMCS lab

clear;clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% loading data and setting data name
% row = input feature, col = input examples
load inout_2
% train, cross-validation, and test set
train_in = mfcc_V(:,1:12000);
train_out = art_V(:,1:12000);
test_in = mfcc_V(:,12001:16000);
test_out = art_V(:,12001:16000);
% train_in = buildingInputs(:,1:3500);
% train_out = buildingTargets(:,1:3500);
% test_in = buildingInputs(:,3501:4208);
% test_out = buildingTargets(:,3501:4208);

% initializing default set
% momentum % learning rate
momentum = 0.9;
learningRate = 0.0001;
epochNum = 50;
% the number of hidden units
hiddenUnit = 50;
% input size
[inputUnit,trainNum] = size(train_in);
% output size
[outputUnit,~] = size(train_out);
% input for start
input_x = train_in;
% output for start
target = train_out;
% the number of input
num_input = size(input_x,1);
% the number of ooutput
num_output = size(train_out,1);
% bias for input layer
hBiasMatrix = ones(1,hiddenUnit);
% bias for hidden layer
oBiasMatrix = ones(1,num_output);
% input to hid weight
range = 0.1;
ihMatrix = rand(num_input, hiddenUnit) * range * 2 - range ;
% hid to output weight
hoMatrix = rand(hiddenUnit, num_output) * range * 2 - range;
% error and recording
sse_keep = [];
sse_history = [];

%% Training procedure.

for epoch = 1:epochNum
    rand_num = randperm(trainNum);
    
    for toss = rand_num
        % distribute vector input
        inputPattern = input_x(:,toss);
        % distribute vector output
        outputPattern = target(:,toss);
        
        % input to hidden layer
        hiddenStorage = inputPattern' * ihMatrix + hBiasMatrix;
        hiddenActivation = BinarySigmoid(momentum,hiddenStorage);

        % hidden to output layer
        outputStorage = hiddenActivation * hoMatrix + oBiasMatrix;
        outputActivation = outputStorage;

        % error calculation
        outputError = outputPattern' - outputActivation;
        hiddenError = outputError * hoMatrix' .* ((hiddenActivation .* (1 - hiddenActivation)) * momentum);
        
        % Weight and bias update
        ihMatrix = ihMatrix + learningRate * inputPattern * hiddenError ;
        hoMatrix = hoMatrix + learningRate * hiddenActivation' * outputError;
        hBiasMatrix = hBiasMatrix + learningRate * hiddenError * 1;
        oBiasMatrix = oBiasMatrix + learningRate * outputError * 1;
        
        sse = trace(outputError' * outputError);
        sse_keep = [sse_keep sse];
    end
    
    % error check and display
    sse_sum = sum(sse_keep)/trainNum;
    sse_history = [sse_history sse_sum];
    fprintf('%d trial: error is %f\n ',epoch,sse_sum)
    sse_keep = [];
   
end

% error trace plotting
plot([1:epochNum],sse_history,'o-k')
xlabel('Epoch Number','fontsize',12)
ylabel('Error','fontsize',12)
title('Error change','fontsize',15)

%% Testing procedure.
testInput = test_in;
testOutput = test_out;
testNum = size(testInput,2);

% training test data with attained weight and bias.
for toss = 1:testNum
    % distribute vector input
    testInputPattern = testInput(:,toss);
    % distribute vector output
    testOutputPattern = testOutput(:,toss);
        
    % input to hidden layer
    testHiddenStorage = testInputPattern' * ihMatrix + hBiasMatrix;
    testHiddenActivation = BinarySigmoid(momentum,testHiddenStorage);
    
    % hidden to output layer
    testOutputStorage = testHiddenActivation * hoMatrix + oBiasMatrix;
    testOutputActivation = testOutputStorage;
    stackedOutput(toss,:) = testOutputActivation;
    
end

% error calculation
testOutputError = (testOutput' - stackedOutput).^2;
resultArray = sum(testOutputError) / 2;
MSE = floor(sum(resultArray)/testNum);
fprintf('MSE: %d\n',MSE)

%% pearson r value and plotting.

% correlation coefficient r
corval = corrcoef(testOutput',stackedOutput);
Rvalue = corval(1,2);

plot(testOutput',stackedOutput,'ok')
title(sprintf('r = %f',Rvalue),'fontsize',15);
axis([-60 20 -60 20])


