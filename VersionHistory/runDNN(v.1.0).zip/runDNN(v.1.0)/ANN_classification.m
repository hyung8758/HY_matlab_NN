% ANN_online : CurveFitting problem (regression)
                                                            % Hyungwon Yang
                                                            % 2015.12.02
                                                            % EMCS lab

clear;clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% loading data and setting data name
% row = the number of examples, col = the number of features
load mnist_classify
% train, and test set
train_in = data;
train_out = labels;
test_in = testdata;
test_out = testlabels;

% Target data reconstruction
% extract the target digits
F_train_out= unique(train_out);
F_test_out = unique(test_out);
num_class = length(F_train_out);

% constrct the target array
train_target = zeros(size(train_out,1), num_class);
test_target = zeros(size(test_out,1),num_class);

for num =1:num_class
    train_target(train_out==F_train_out(num),num)=1;
    test_target(test_out==F_test_out(num),num)=1;
end
% rename the variable names
train_out = train_target;
test_out = test_target;

% initializing default set
% momentum % learning rate
momentum = 0.9;
learningRate = 0.001;
epochNum = 100;
% the number of hidden units
hiddenUnit = 50;
% input size
[inputUnit,trainNum] = size(train_in);
% output size
[outputUnit,~] = size(train_out);
% input for start
input_x = train_in;
% output for start
target = train_out;
% the number of input
num_input = size(input_x,2);
% the number of ooutput
num_output = size(train_out,2);
% bias for input layer
hBiasMatrix = ones(1,hiddenUnit);
% bias for hidden layer
oBiasMatrix = ones(1,num_output);
% input to hid weight
range = 0.1;
ihMatrix = rand(num_input, hiddenUnit) * range * 2 - range ;
% hid to output weight
hoMatrix = rand(hiddenUnit, num_output) * range * 2 - range;
% error and recording
sse_keep = [];
sse_history = [];

%% Training procedure.

for epoch = 1:epochNum
    rand_num = randperm(trainNum);
    
    for toss = rand_num
        % distribute vector input
        inputPattern = input_x(toss,:);
        % distribute vector output
        outputPattern = target(toss,:);
        
        % input to hidden layer
        hiddenStorage = inputPattern * ihMatrix + hBiasMatrix;
        hiddenActivation = BinarySigmoid(momentum,hiddenStorage);

        % hidden to output layer
        outputStorage = hiddenActivation * hoMatrix + oBiasMatrix;
        outputActivation = ml_softmax(outputStorage);

        % error calculation
        outputError = outputPattern - outputActivation;
        hiddenError = outputError * hoMatrix' .* ((hiddenActivation .* (1 - hiddenActivation)) * momentum);
        
        % Weight and bias update
        ihMatrix = ihMatrix + learningRate * inputPattern' * hiddenError ;
        hoMatrix = hoMatrix + learningRate * hiddenActivation' * outputError;
        hBiasMatrix = hBiasMatrix + learningRate * hiddenError * 1;
        oBiasMatrix = oBiasMatrix + learningRate * outputError * 1;
        
        sse = -sum(outputPattern * log(outputActivation)');
        sse_keep = [sse_keep sse];
    end
    
    % error check and display
    sse_sum = sum(sse_keep)/trainNum;
    sse_history = [sse_history sse_sum];
    fprintf('%d trial: error is %f\n ',epoch,sse_sum)
    sse_keep = [];
   
end

% error trace plotting
plot([1:epochNum],sse_history,'o-k')
xlabel('Epoch Number','fontsize',12)
ylabel('Error','fontsize',12)
title('Error change','fontsize',15)

%% Testing procedure.
testInput = test_in;
testOutput = test_out;
testNum = size(testInput,1);

% training test data with attained weight and bias.
for toss = 1:testNum
    % distribute vector input
    testInputPattern = testInput(toss,:);
    % distribute vector output
    testOutputPattern = testOutput(toss,:);
        
    % input to hidden layer
    testHiddenStorage = testInputPattern * ihMatrix + hBiasMatrix;
    testHiddenActivation = BinarySigmoid(momentum,testHiddenStorage);
    
    % hidden to output layer
    testOutputStorage = testHiddenActivation * hoMatrix + oBiasMatrix;
    testOutputActivation = ml_softmax(testOutputStorage);
    stackedOutput(toss,:) = testOutputActivation;
    
    max_idx = max(testOutputActivation);
    pred_result = find(testOutputActivation == max_idx);
    test_result = find(testOutput(toss,:) == 1);
    
    if pred_result == test_result;
        resultArray(toss) = 1;
    else
        resultArray(toss) = 0;
    end
end

% accuracy calculation based on the prediction
testAccuracy = round((sum(resultArray) / testNum)*100,2);
fprintf('Testing complete.Test Accuracy: %4.2f\n',testAccuracy)


